Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ==========================================
# 1. GESTIONE LINGUA E TESTI
# ==========================================
$langDict = @{
    "IT" = @{
        "Title" = "Assetto Corsa Rally - Launcher";
        "TabPlay" = "  Gioca  ";
        "TabAdv" = "  Avanzate  ";
        "TabInfo" = "  Info  ";
        "Platform" = "Piattaforma:";
        "Path" = "Percorso Eseguibile:";
        "Browse" = "Sfoglia...";
        "Launch" = "AVVIA MOTORE";
        "VideoOpt" = "Opzioni Video & Performance";
        "ForceDX11" = "Forza DirectX 11 (-dx11)";
        "Windowed" = "Modalità Finestra (-windowed)";
        "HighPrio" = "Boost Priorità CPU (High)";
        "DisplayMode" = "Modalità Visualizzazione:";
        "Monitor" = "Monitor Standard";
        "OpenVR" = "SteamVR (OpenVR)";
        "Oculus" = "Oculus VR";
        "CloseLauncher" = "Chiudi launcher all'avvio";
        "CustomArgs" = "Argomenti extra:";
        "Maintenance" = "Manutenzione & ReShade";
        "ClearCache" = "PANIC BUTTON: Pulisci Cache";
        "CleanConfirm" = "ATTENZIONE: Questo cancellerà le impostazioni video e i controlli salvati (UserGameSettings). Continuare?";
        "ReShadeOn" = "ReShade: ATTIVO (Disabilita)";
        "ReShadeOff" = "ReShade: DISATTIVO (Abilita)";
        "ReShadeNo" = "ReShade non installato (dxgi.dll)";
        "RunningWarn" = "Il gioco è già in esecuzione!";
        "Links" = "Link Utili";
        "OpenLogs" = "Apri Log";
        "OpenMods" = "Apri Mods";
        "WebSite" = "Sito Web";
        
        "StatusReady" = "Pronto alla partenza";
        "StatusSearch" = "Ricerca eseguibile...";
        "StatusErr" = "Errore: Eseguibile non trovato";
        "StatusRun" = "Gioco in esecuzione...";
        "StatusManual" = "Percorso manuale selezionato"
    };
    "EN" = @{
        "Title" = "Assetto Corsa Rally - Launcher";
        "TabPlay" = "  Play  ";
        "TabAdv" = "  Advanced  ";
        "TabInfo" = "  Info  ";
        "Platform" = "Platform:";
        "Path" = "Executable Path:";
        "Browse" = "Browse...";
        "Launch" = "START ENGINE";
        "VideoOpt" = "Video & Performance Options";
        "ForceDX11" = "Force DirectX 11 (-dx11)";
        "Windowed" = "Windowed Mode (-windowed)";
        "HighPrio" = "CPU Priority Boost (High)";
        "DisplayMode" = "Display Mode:";
        "Monitor" = "Standard Monitor";
        "OpenVR" = "SteamVR (OpenVR)";
        "Oculus" = "Oculus VR";
        "CloseLauncher" = "Close launcher on start";
        "CustomArgs" = "Extra Arguments:";
        "Maintenance" = "Maintenance & ReShade";
        "ClearCache" = "PANIC BUTTON: Clear Cache";
        "CleanConfirm" = "WARNING: This will wipe video settings and saved controls (UserGameSettings). Continue?";
        "ReShadeOn" = "ReShade: ACTIVE (Disable)";
        "ReShadeOff" = "ReShade: DISABLED (Enable)";
        "ReShadeNo" = "ReShade not found (dxgi.dll)";
        "RunningWarn" = "Game is already running!";
        "Links" = "Useful Links";
        "OpenLogs" = "Open Logs";
        "OpenMods" = "Open Mods";
        "WebSite" = "Website";

        "StatusReady" = "Ready to race";
        "StatusSearch" = "Searching executable...";
        "StatusErr" = "Error: Executable missing";
        "StatusRun" = "Game is running...";
        "StatusManual" = "Manual path selected"
    }
}

$global:currentLang = "IT"
$global:currentStatusKey = "StatusSearch"

# ==========================================
# 2. CONFIGURAZIONE
# ==========================================
$configFile = Join-Path $PSScriptRoot "acr_config.json"

function Get-Config {
    if (Test-Path $configFile) {
        try { return Get-Content $configFile -Raw | ConvertFrom-Json } catch { return $null }
    }
    return $null
}

function Save-Config {
    $config = @{
        Path = $pathTextBox.Text
        PlatformIdx = $platformCombo.SelectedIndex
        DX11 = $dx11Check.Checked
        Windowed = $windowCheck.Checked
        HighPrio = $prioCheck.Checked
        VRMode = $vrCombo.SelectedIndex
        CloseOnStart = $closeCheck.Checked
        CustomArgs = $argsBox.Text
        Language = $global:currentLang
    }
    $config | ConvertTo-Json | Set-Content $configFile
}

# ==========================================
# 3. INTERFACCIA GRAFICA (GUI)
# ==========================================
$form = New-Object System.Windows.Forms.Form
$form.Text = "Assetto Corsa Rally - Launcher"
$form.Size = New-Object System.Drawing.Size(550, 600)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(32, 32, 32)
$form.ForeColor = [System.Drawing.Color]::White

# --- Header ---
$headerPanel = New-Object System.Windows.Forms.Panel
$headerPanel.Size = New-Object System.Drawing.Size(550, 50)
$headerPanel.Dock = "Top"
$headerPanel.BackColor = [System.Drawing.Color]::FromArgb(45, 45, 48)
$form.Controls.Add($headerPanel)

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$titleLabel.ForeColor = [System.Drawing.Color]::Orange
$titleLabel.Location = New-Object System.Drawing.Point(10, 15)
$titleLabel.Size = New-Object System.Drawing.Size(300, 30)
$headerPanel.Controls.Add($titleLabel)

$langButton = New-Object System.Windows.Forms.Button
$langButton.Text = "IT / EN"
$langButton.Location = New-Object System.Drawing.Point(440, 10)
$langButton.Size = New-Object System.Drawing.Size(80, 30)
$langButton.FlatStyle = "Flat"
$langButton.ForeColor = [System.Drawing.Color]::White
$langButton.BackColor = [System.Drawing.Color]::FromArgb(60,60,60)
$headerPanel.Controls.Add($langButton)

# --- Tab Control --- CORRETTO!
$tabControl = New-Object System.Windows.Forms.TabControl
$tabControl.Location = New-Object System.Drawing.Point(0, 50)
$tabControl.Size = New-Object System.Drawing.Size(550, 550)
$tabControl.Padding = New-Object System.Drawing.Point(10, 6)
$tabControl.Appearance = "Normal"
$tabControl.BackColor = [System.Drawing.Color]::FromArgb(45, 45, 48)
$tabControl.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($tabControl)

# Crea le schede
$tabPlay = New-Object System.Windows.Forms.TabPage
$tabPlay.Name = "tabPlay"
$tabPlay.Text = "  Gioca  "
$tabPlay.BackColor = [System.Drawing.Color]::FromArgb(40, 40, 40)
$tabPlay.ForeColor = [System.Drawing.Color]::White
$tabControl.TabPages.Add($tabPlay)

$tabAdv = New-Object System.Windows.Forms.TabPage
$tabAdv.Name = "tabAdv"
$tabAdv.Text = "  Avanzate  "
$tabAdv.BackColor = [System.Drawing.Color]::FromArgb(40, 40, 40)
$tabAdv.ForeColor = [System.Drawing.Color]::White
$tabControl.TabPages.Add($tabAdv)

$tabInfo = New-Object System.Windows.Forms.TabPage
$tabInfo.Name = "tabInfo"
$tabInfo.Text = "  Info  "
$tabInfo.BackColor = [System.Drawing.Color]::FromArgb(40, 40, 40)
$tabInfo.ForeColor = [System.Drawing.Color]::White
$tabControl.TabPages.Add($tabInfo)

# --- TAB: GIOCA ---
$lblPlatform = New-Object System.Windows.Forms.Label
$lblPlatform.Location = New-Object System.Drawing.Point(20, 20)
$lblPlatform.Size = New-Object System.Drawing.Size(200, 20)
$tabPlay.Controls.Add($lblPlatform)

$platformCombo = New-Object System.Windows.Forms.ComboBox
$platformCombo.Location = New-Object System.Drawing.Point(20, 45)
$platformCombo.Size = New-Object System.Drawing.Size(200, 25)
$platformCombo.DropDownStyle = "DropDownList"
$platformCombo.Items.AddRange(@("Auto-Detect", "Steam", "Epic Games", "Manual Path"))
$platformCombo.SelectedIndex = 0
$tabPlay.Controls.Add($platformCombo)

$lblPath = New-Object System.Windows.Forms.Label
$lblPath.Location = New-Object System.Drawing.Point(20, 80)
$lblPath.Size = New-Object System.Drawing.Size(200, 20)
$tabPlay.Controls.Add($lblPath)

$pathTextBox = New-Object System.Windows.Forms.TextBox
$pathTextBox.Location = New-Object System.Drawing.Point(20, 105)
$pathTextBox.Size = New-Object System.Drawing.Size(400, 25)
$pathTextBox.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 60)
$pathTextBox.ForeColor = [System.Drawing.Color]::White
$tabPlay.Controls.Add($pathTextBox)

$browseBtn = New-Object System.Windows.Forms.Button
$browseBtn.Location = New-Object System.Drawing.Point(430, 103)
$browseBtn.Size = New-Object System.Drawing.Size(75, 25)
$browseBtn.FlatStyle = "Flat"
$browseBtn.ForeColor = [System.Drawing.Color]::White
$browseBtn.BackColor = [System.Drawing.Color]::FromArgb(70, 70, 70)
$tabPlay.Controls.Add($browseBtn)

# GRUPPO VIDEO
$grpVideo = New-Object System.Windows.Forms.GroupBox
$grpVideo.Location = New-Object System.Drawing.Point(20, 150)
$grpVideo.Size = New-Object System.Drawing.Size(485, 140)
$grpVideo.ForeColor = [System.Drawing.Color]::White
$grpVideo.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 50)
$tabPlay.Controls.Add($grpVideo)

$dx11Check = New-Object System.Windows.Forms.CheckBox
$dx11Check.Location = New-Object System.Drawing.Point(20, 30)
$dx11Check.Size = New-Object System.Drawing.Size(200, 20)
$grpVideo.Controls.Add($dx11Check)

$windowCheck = New-Object System.Windows.Forms.CheckBox
$windowCheck.Location = New-Object System.Drawing.Point(20, 60)
$windowCheck.Size = New-Object System.Drawing.Size(200, 20)
$grpVideo.Controls.Add($windowCheck)

$prioCheck = New-Object System.Windows.Forms.CheckBox
$prioCheck.Location = New-Object System.Drawing.Point(20, 90)
$prioCheck.Size = New-Object System.Drawing.Size(250, 20)
$prioCheck.ForeColor = [System.Drawing.Color]::LightGoldenrodYellow
$grpVideo.Controls.Add($prioCheck)

$lblDisplay = New-Object System.Windows.Forms.Label
$lblDisplay.Location = New-Object System.Drawing.Point(250, 30)
$lblDisplay.Size = New-Object System.Drawing.Size(200, 20)
$grpVideo.Controls.Add($lblDisplay)

$vrCombo = New-Object System.Windows.Forms.ComboBox
$vrCombo.Location = New-Object System.Drawing.Point(250, 55)
$vrCombo.Size = New-Object System.Drawing.Size(200, 25)
$vrCombo.DropDownStyle = "DropDownList"
$grpVideo.Controls.Add($vrCombo)

# PULSANTE AVVIO
$launchBtn = New-Object System.Windows.Forms.Button
$launchBtn.Location = New-Object System.Drawing.Point(130, 310)
$launchBtn.Size = New-Object System.Drawing.Size(260, 50)
$launchBtn.BackColor = [System.Drawing.Color]::FromArgb(200, 80, 0)
$launchBtn.ForeColor = [System.Drawing.Color]::White
$launchBtn.Font = New-Object System.Drawing.Font("Arial", 12, [System.Drawing.FontStyle]::Bold)
$launchBtn.FlatStyle = "Flat"
$launchBtn.Cursor = [System.Windows.Forms.Cursors]::Hand
$tabPlay.Controls.Add($launchBtn)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Location = New-Object System.Drawing.Point(20, 380)
$statusLabel.Size = New-Object System.Drawing.Size(485, 25)
$statusLabel.TextAlign = "MiddleCenter"
$statusLabel.Font = New-Object System.Drawing.Font("Arial", 10, [System.Drawing.FontStyle]::Bold)
$tabPlay.Controls.Add($statusLabel)

# --- TAB: AVANZATE ---
$lblArgs = New-Object System.Windows.Forms.Label
$lblArgs.Location = New-Object System.Drawing.Point(20, 20)
$lblArgs.Size = New-Object System.Drawing.Size(300, 20)
$tabAdv.Controls.Add($lblArgs)

$argsBox = New-Object System.Windows.Forms.TextBox
$argsBox.Location = New-Object System.Drawing.Point(20, 45)
$argsBox.Size = New-Object System.Drawing.Size(485, 25)
$argsBox.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 60)
$argsBox.ForeColor = [System.Drawing.Color]::White
$tabAdv.Controls.Add($argsBox)

$closeCheck = New-Object System.Windows.Forms.CheckBox
$closeCheck.Location = New-Object System.Drawing.Point(20, 90)
$closeCheck.Size = New-Object System.Drawing.Size(400, 20)
$closeCheck.ForeColor = [System.Drawing.Color]::White
$tabAdv.Controls.Add($closeCheck)

# GRUPPO MANUTENZIONE
$grpPanic = New-Object System.Windows.Forms.GroupBox
$grpPanic.Location = New-Object System.Drawing.Point(20, 140)
$grpPanic.Size = New-Object System.Drawing.Size(485, 160)
$grpPanic.ForeColor = [System.Drawing.Color]::White
$grpPanic.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 50)
$tabAdv.Controls.Add($grpPanic)

# Pulsante ReShade
$btnReShade = New-Object System.Windows.Forms.Button
$btnReShade.Location = New-Object System.Drawing.Point(20, 30)
$btnReShade.Size = New-Object System.Drawing.Size(445, 35)
$btnReShade.FlatStyle = "Flat"
$btnReShade.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 60)
$btnReShade.ForeColor = [System.Drawing.Color]::White
$grpPanic.Controls.Add($btnReShade)

# Pulsante Cache (Panic)
$btnCleanCache = New-Object System.Windows.Forms.Button
$btnCleanCache.Location = New-Object System.Drawing.Point(20, 80)
$btnCleanCache.Size = New-Object System.Drawing.Size(445, 40)
$btnCleanCache.BackColor = [System.Drawing.Color]::DarkRed
$btnCleanCache.ForeColor = [System.Drawing.Color]::White
$btnCleanCache.FlatStyle = "Flat"
$btnCleanCache.Font = New-Object System.Drawing.Font("Arial", 10, [System.Drawing.FontStyle]::Bold)
$grpPanic.Controls.Add($btnCleanCache)

# --- TAB: INFO ---
$btnLogs = New-Object System.Windows.Forms.Button
$btnLogs.Location = New-Object System.Drawing.Point(30, 40)
$btnLogs.Size = New-Object System.Drawing.Size(200, 35)
$btnLogs.FlatStyle = "Flat"
$btnLogs.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 70)
$btnLogs.ForeColor = [System.Drawing.Color]::White
$tabInfo.Controls.Add($btnLogs)

$btnMods = New-Object System.Windows.Forms.Button
$btnMods.Location = New-Object System.Drawing.Point(30, 90)
$btnMods.Size = New-Object System.Drawing.Size(200, 35)
$btnMods.FlatStyle = "Flat"
$btnMods.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 70)
$btnMods.ForeColor = [System.Drawing.Color]::White
$tabInfo.Controls.Add($btnMods)

$linkWeb = New-Object System.Windows.Forms.LinkLabel
$linkWeb.Location = New-Object System.Drawing.Point(30, 150)
$linkWeb.Size = New-Object System.Drawing.Size(300, 25)
$linkWeb.LinkColor = [System.Drawing.Color]::LightSkyBlue
$linkWeb.ActiveLinkColor = [System.Drawing.Color]::Cyan
$tabInfo.Controls.Add($linkWeb)

# ==========================================
# 4. LOGICA AGGIORNATA
# ==========================================

function Update-UI {
    $T = $langDict[$global:currentLang]
    
    $form.Text = $T.Title  # AGGIUNTO: Aggiorna titolo finestra
    $titleLabel.Text = $T.Title
    $tabPlay.Text = $T.TabPlay
    $tabAdv.Text = $T.TabAdv
    $tabInfo.Text = $T.TabInfo
    
    # Label Play
    $lblPlatform.Text = $T.Platform
    $lblPath.Text = $T.Path
    $browseBtn.Text = $T.Browse
    $launchBtn.Text = $T.Launch
    $grpVideo.Text = $T.VideoOpt
    $dx11Check.Text = $T.ForceDX11
    $windowCheck.Text = $T.Windowed
    $prioCheck.Text = $T.HighPrio
    $lblDisplay.Text = $T.DisplayMode
    
    # Label Adv
    $lblArgs.Text = $T.CustomArgs
    $closeCheck.Text = $T.CloseLauncher
    $grpPanic.Text = $T.Maintenance
    $btnCleanCache.Text = $T.ClearCache
    
    # Label Info
    $btnLogs.Text = $T.OpenLogs
    $btnMods.Text = $T.OpenMods
    $linkWeb.Text = $T.WebSite

    # VR Combo
    $sel = $vrCombo.SelectedIndex
    $vrCombo.Items.Clear()
    $vrCombo.Items.Add($T.Monitor)
    $vrCombo.Items.Add($T.OpenVR)
    $vrCombo.Items.Add($T.Oculus)
    if ($sel -ge 0) { $vrCombo.SelectedIndex = $sel } else { $vrCombo.SelectedIndex = 0 }

    # Status
    $statusLabel.Text = $T[$global:currentStatusKey]
    switch ($global:currentStatusKey) {
        "StatusReady" { $statusLabel.ForeColor = [System.Drawing.Color]::LightGreen }
        "StatusErr"   { $statusLabel.ForeColor = [System.Drawing.Color]::Red }
        "StatusSearch"{ $statusLabel.ForeColor = [System.Drawing.Color]::Yellow }
        "StatusManual"{ $statusLabel.ForeColor = [System.Drawing.Color]::Cyan }
        Default       { $statusLabel.ForeColor = [System.Drawing.Color]::White }
    }

    # Logica testo ReShade
    if ($pathTextBox.Text -and (Test-Path $pathTextBox.Text)) {
        $dir = [System.IO.Path]::GetDirectoryName($pathTextBox.Text)
        if (Test-Path "$dir\dxgi.dll") {
            $btnReShade.Text = $T.ReShadeOn
            $btnReShade.ForeColor = [System.Drawing.Color]::LightGreen
            $btnReShade.BackColor = [System.Drawing.Color]::FromArgb(30, 60, 30)
        } elseif (Test-Path "$dir\dxgi.dll.off") {
            $btnReShade.Text = $T.ReShadeOff
            $btnReShade.ForeColor = [System.Drawing.Color]::Orange
            $btnReShade.BackColor = [System.Drawing.Color]::FromArgb(60, 40, 10)
        } else {
            $btnReShade.Text = $T.ReShadeNo
            $btnReShade.ForeColor = [System.Drawing.Color]::Gray
            $btnReShade.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 60)
        }
    } else {
        $btnReShade.Text = $T.ReShadeNo
        $btnReShade.ForeColor = [System.Drawing.Color]::Gray
        $btnReShade.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 60)
    }

    $form.Refresh()
}

$langButton.add_Click({
    if ($global:currentLang -eq "IT") { $global:currentLang = "EN" } else { $global:currentLang = "IT" }
    Update-UI
})

$acrPaths = @(
    "C:\Program Files (x86)\Steam\steamapps\common\Assetto Corsa Rally\acr.exe",
    "D:\SteamLibrary\steamapps\common\Assetto Corsa Rally\acr.exe",
    "C:\Program Files\Epic Games\AssettoCorsaRally\acr.exe"
)

function Find-Game {
    if ($platformCombo.SelectedItem -eq "Manual Path") { return }
    $global:currentStatusKey = "StatusSearch"
    Update-UI 
    $found = $false
    foreach ($p in $acrPaths) {
        if (Test-Path $p) {
            $pathTextBox.Text = $p
            $global:currentStatusKey = "StatusReady"
            $found = $true
            try { $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($p) } catch {}
            break
        }
    }
    if (-not $found) { $pathTextBox.Text = ""; $global:currentStatusKey = "StatusErr" }
    Update-UI 
}

$platformCombo.add_SelectedIndexChanged({ 
    if ($platformCombo.SelectedItem -eq "Manual Path") {
         $global:currentStatusKey = "StatusManual"
    } else {
         Find-Game 
    }
    Update-UI
})

$browseBtn.add_Click({
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = "ACR Executable (*.exe)|*.exe"
    if ($ofd.ShowDialog() -eq "OK") {
        $pathTextBox.Text = $ofd.FileName
        $platformCombo.SelectedIndex = 3 
        $global:currentStatusKey = "StatusManual"
        Update-UI
        try { $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($ofd.FileName) } catch {}
    }
})

# --- EVENTI PULSANTI AVANZATI ---

# Toggle ReShade
$btnReShade.add_Click({
    if (-not $pathTextBox.Text) { return }
    $dir = [System.IO.Path]::GetDirectoryName($pathTextBox.Text)
    $on = "$dir\dxgi.dll"
    $off = "$dir\dxgi.dll.off"

    if (Test-Path $on) {
        Rename-Item $on "dxgi.dll.off"
    } elseif (Test-Path $off) {
        Rename-Item $off "dxgi.dll"
    }
    Update-UI 
})

# Clean Cache
$btnCleanCache.add_Click({
    $T = $langDict[$global:currentLang]
    $res = [System.Windows.Forms.MessageBox]::Show($T.CleanConfirm, "Warning", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
    
    if ($res -eq "Yes") {
        # Percorso standard UE4/UE5
        $configPath = "$env:LOCALAPPDATA\AssettoCorsaRally\Saved\Config\WindowsNoEditor"
        if (Test-Path $configPath) {
            try {
                Get-ChildItem -Path $configPath -Filter "*.ini" | Remove-Item -Force
                [System.Windows.Forms.MessageBox]::Show("Cache pulita correttamente (File .ini rimossi).", "Success")
            } catch {
                [System.Windows.Forms.MessageBox]::Show("Errore durante la pulizia: $_", "Error")
            }
        } else {
             [System.Windows.Forms.MessageBox]::Show("Cartella Config non trovata. Il gioco è mai stato avviato?", "Info")
        }
    }
})

# Launch Logic
$launchBtn.add_Click({
    $exe = $pathTextBox.Text
    $T = $langDict[$global:currentLang]

    if (-not (Test-Path $exe)) {
        $global:currentStatusKey = "StatusErr"
        Update-UI
        return
    }

    $procName = [System.IO.Path]::GetFileNameWithoutExtension($exe)
    if (Get-Process -Name $procName -ErrorAction SilentlyContinue) {
        [System.Windows.Forms.MessageBox]::Show($T.RunningWarn, "Warning", 0, 48)
        return
    }

    $argsList = New-Object System.Collections.Generic.List[string]
    if ($dx11Check.Checked) { $argsList.Add("-dx11") }
    if ($windowCheck.Checked) { $argsList.Add("-windowed") }
    switch ($vrCombo.SelectedIndex) {
        1 { $argsList.Add("-openvr"); $argsList.Add("-vr") }
        2 { $argsList.Add("-oculus"); $argsList.Add("-vr") }
    }
    if (-not [string]::IsNullOrWhiteSpace($argsBox.Text)) { $argsList.Add($argsBox.Text) }

    Save-Config
    
    try {
        $global:currentStatusKey = "StatusRun"
        Update-UI
        
        $proc = Start-Process -FilePath $exe -ArgumentList $argsList -PassThru
        
        if ($prioCheck.Checked) {
            try { $proc.PriorityClass = [System.Diagnostics.ProcessPriorityClass]::High } catch {}
        }

        if ($closeCheck.Checked) { $form.Close() }
    } catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, "Error")
    }
})

$linkWeb.add_Click({ Start-Process "https://assettocorsa.gg/assetto-corsa-rally/" })

$btnLogs.add_Click({ 
    $logPath = "$env:LOCALAPPDATA\AssettoCorsaRally\Saved\Logs"
    if (-not (Test-Path $logPath)) { New-Item -ItemType Directory -Force -Path $logPath | Out-Null }
    Invoke-Item $logPath 
})

# Handler per pulsante Mods
$btnMods.add_Click({ 
    if ($pathTextBox.Text -and (Test-Path $pathTextBox.Text)) {
        $gameDir = Split-Path $pathTextBox.Text -Parent
        $modsPath = Join-Path $gameDir "mods"
        
        if (-not (Test-Path $modsPath)) { 
            $modsPath = Join-Path $gameDir "content"
        }
        
        if (-not (Test-Path $modsPath)) {
            $modsPath = Join-Path (Split-Path $gameDir -Parent) "mods"
        }
        
        if (Test-Path $modsPath) {
            Invoke-Item $modsPath 
        } else {
            $T = $langDict[$global:currentLang]
            [System.Windows.Forms.MessageBox]::Show("Cartella mods non trovata. Apro la directory del gioco.", "Info")
            Invoke-Item $gameDir
        }
    } else {
        $T = $langDict[$global:currentLang]
        [System.Windows.Forms.MessageBox]::Show($T.StatusErr, "Info")
    }
})

# --- AVVIO ---
$savedConfig = Get-Config
if ($savedConfig) {
    if ($savedConfig.Path) { $pathTextBox.Text = $savedConfig.Path }
    if ($savedConfig.PlatformIdx) { $platformCombo.SelectedIndex = $savedConfig.PlatformIdx }
    if ($savedConfig.DX11) { $dx11Check.Checked = $savedConfig.DX11 }
    if ($savedConfig.Windowed) { $windowCheck.Checked = $savedConfig.Windowed }
    if ($savedConfig.HighPrio) { $prioCheck.Checked = $savedConfig.HighPrio }
    if ($savedConfig.VRMode) { $vrCombo.SelectedIndex = $savedConfig.VRMode }
    if ($savedConfig.CloseOnStart) { $closeCheck.Checked = $savedConfig.CloseOnStart }
    if ($savedConfig.CustomArgs) { $argsBox.Text = $savedConfig.CustomArgs }
    if ($savedConfig.Language) { $global:currentLang = $savedConfig.Language }
} else {
    $platformCombo.SelectedIndex = 0
}

Update-UI
[void]$form.ShowDialog()