<#
    ACR Launcher v0.0.4.0 - Gemini Pro Optimized
    Corrections:
    1. Simplified Platform Selection (Auto-Detect only).
    2. Updated UE4/UE5 Config Paths (\acr\Saved\...).
    3. Fixed Process Priority Crash (HasExited check).
    4. Non-freezing deep scan logic.
#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ==========================================
# 1. GESTIONE LINGUA E TESTI
# ==========================================
$langDict = @{
    "IT" = @{
        "Title" = "Assetto Corsa Rally - Launcher";
        "TabPlay" = "  Gioca  ";
        "TabAdv" = "  Avanzate  ";
        "TabInfo" = "  Info  ";
        "Platform" = "Metodo Rilevamento:";
        "Path" = "Percorso Eseguibile (acr.exe):";
        "Browse" = "Sfoglia...";
        "Launch" = "AVVIA MOTORE";
        "VideoOpt" = "Opzioni Video & Performance";
        "ForceDX11" = "Forza DirectX 11 (-dx11)";
        "Windowed" = "Modalità Finestra (-windowed)";
        "HighPrio" = "Boost Priorità CPU (High)";
        "DisplayMode" = "Modalità Visualizzazione:";
        "Monitor" = "Monitor Standard";
        "OpenVR" = "SteamVR (OpenVR)";
        "Oculus" = "Oculus VR";
        "CloseLauncher" = "Chiudi launcher all'avvio";
        "CustomArgs" = "Argomenti extra:";
        "Maintenance" = "Manutenzione & ReShade";
        "ClearCache" = "PANIC BUTTON: Pulisci Cache";
        "CleanConfirm" = "ATTENZIONE: Questo cancellerà le impostazioni video (GameUserSettings.ini). Continuare?";
        "ReShadeOn" = "ReShade: ATTIVO (Disabilita)";
        "ReShadeOff" = "ReShade: DISATTIVO (Abilita)";
        "ReShadeNo" = "ReShade non installato (dxgi.dll)";
        "RunningWarn" = "Il gioco è già in esecuzione!";
        "Links" = "Link Utili";
        "OpenLogs" = "Apri Log";
        "OpenMods" = "Apri Mods";
        "WebSite" = "Sito Web Ufficiale";
        "MissingMsg" = "Eseguibile acr.exe non trovato!`n`nVuoi aprire la pagina ufficiale per scaricare il gioco?";
        
        "StatusReady" = "Pronto alla partenza";
        "StatusSearch" = "Ricerca eseguibile in corso...";
        "StatusErr" = "Errore: Eseguibile non trovato";
        "StatusRun" = "Gioco in esecuzione...";
        "StatusManual" = "Percorso manuale selezionato"
    };
    "EN" = @{
        "Title" = "Assetto Corsa Rally - Launcher";
        "TabPlay" = "  Play  ";
        "TabAdv" = "  Advanced  ";
        "TabInfo" = "  Info  ";
        "Platform" = "Detection Method:";
        "Path" = "Executable Path (acr.exe):";
        "Browse" = "Browse...";
        "Launch" = "START ENGINE";
        "VideoOpt" = "Video & Performance Options";
        "ForceDX11" = "Force DirectX 11 (-dx11)";
        "Windowed" = "Windowed Mode (-windowed)";
        "HighPrio" = "CPU Priority Boost (High)";
        "DisplayMode" = "Display Mode:";
        "Monitor" = "Standard Monitor";
        "OpenVR" = "SteamVR (OpenVR)";
        "Oculus" = "Oculus VR";
        "CloseLauncher" = "Close launcher on start";
        "CustomArgs" = "Extra Arguments:";
        "Maintenance" = "Maintenance & ReShade";
        "ClearCache" = "PANIC BUTTON: Clear Cache";
        "CleanConfirm" = "WARNING: This will wipe video settings (GameUserSettings.ini). Continue?";
        "ReShadeOn" = "ReShade: ACTIVE (Disable)";
        "ReShadeOff" = "ReShade: DISABLED (Enable)";
        "ReShadeNo" = "ReShade not found (dxgi.dll)";
        "RunningWarn" = "Game is already running!";
        "Links" = "Useful Links";
        "OpenLogs" = "Open Logs";
        "OpenMods" = "Open Mods";
        "WebSite" = "Official Website";
        "MissingMsg" = "Executable acr.exe not found!`n`nDo you want to open the official page to download the game?";

        "StatusReady" = "Ready to race";
        "StatusSearch" = "Searching executable...";
        "StatusErr" = "Error: Executable missing";
        "StatusRun" = "Game is running...";
        "StatusManual" = "Manual path selected"
    }
}

$global:currentLang = "IT"
$global:currentStatusKey = "StatusSearch"
# Percorso corretto UE4/UE5 per ACR
$global:gameConfigDir = "$env:LOCALAPPDATA\acr\Saved\Config\Windows"

# ==========================================
# 2. CONFIGURAZIONE
# ==========================================
$appDataDir = Join-Path $env:APPDATA "ACRLauncher"
if (-not (Test-Path $appDataDir)) {
    New-Item -ItemType Directory -Path $appDataDir -Force | Out-Null
}

$configFile = Join-Path $appDataDir "acr_config.json"

function Get-Config {
    if (Test-Path $configFile) {
        try {
            $json = [System.IO.File]::ReadAllText($configFile, [System.Text.Encoding]::UTF8)
            return $json | ConvertFrom-Json
        }
        catch { return $null }
    }
    return $null
}

function Save-Config {
    try {
        $config = @{
            Path        = $pathTextBox.Text
            DX11        = $dx11Check.Checked
            Windowed    = $windowCheck.Checked
            HighPrio    = $prioCheck.Checked
            VRMode      = $vrCombo.SelectedIndex
            CloseOnStart= $closeCheck.Checked
            CustomArgs  = $argsBox.Text
            Language    = $global:currentLang
        }
        $json = $config | ConvertTo-Json -Depth 3
        [System.IO.File]::WriteAllText($configFile, $json, [System.Text.Encoding]::UTF8)
    }
    catch {
        Write-Host "Errore salvataggio config: $_"
    }
}

# ==========================================
# 3. INTERFACCIA GRAFICA (GUI)
# ==========================================
$form = New-Object System.Windows.Forms.Form
$form.Text = "Assetto Corsa Rally - Launcher"
$form.Size = New-Object System.Drawing.Size(550, 600)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(32, 32, 32)
$form.ForeColor = [System.Drawing.Color]::White

# --- Header ---
$headerPanel = New-Object System.Windows.Forms.Panel
$headerPanel.Size = New-Object System.Drawing.Size(550, 50)
$headerPanel.Dock = "Top"
$headerPanel.BackColor = [System.Drawing.Color]::FromArgb(45, 45, 48)
$form.Controls.Add($headerPanel)

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$titleLabel.ForeColor = [System.Drawing.Color]::Orange
$titleLabel.Location = New-Object System.Drawing.Point(10, 15)
$titleLabel.Size = New-Object System.Drawing.Size(300, 30)
$headerPanel.Controls.Add($titleLabel)

$langButton = New-Object System.Windows.Forms.Button
$langButton.Text = "IT / EN"
$langButton.Location = New-Object System.Drawing.Point(440, 10)
$langButton.Size = New-Object System.Drawing.Size(80, 30)
$langButton.FlatStyle = "Flat"
$langButton.ForeColor = [System.Drawing.Color]::White
$langButton.BackColor = [System.Drawing.Color]::FromArgb(60,60,60)
$headerPanel.Controls.Add($langButton)

# --- Tab Control ---
$tabControl = New-Object System.Windows.Forms.TabControl
$tabControl.Location = New-Object System.Drawing.Point(0, 50)
$tabControl.Size = New-Object System.Drawing.Size(550, 550)
$tabControl.Padding = New-Object System.Drawing.Point(10, 6)
$tabControl.Appearance = "Normal"
$tabControl.BackColor = [System.Drawing.Color]::FromArgb(45, 45, 48)
$tabControl.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($tabControl)

# Crea le schede
$tabPlay = New-Object System.Windows.Forms.TabPage; $tabPlay.Name="tabPlay"; $tabPlay.BackColor=[System.Drawing.Color]::FromArgb(40,40,40)
$tabAdv = New-Object System.Windows.Forms.TabPage; $tabAdv.Name="tabAdv"; $tabAdv.BackColor=[System.Drawing.Color]::FromArgb(40,40,40)
$tabInfo = New-Object System.Windows.Forms.TabPage; $tabInfo.Name="tabInfo"; $tabInfo.BackColor=[System.Drawing.Color]::FromArgb(40,40,40)

$tabControl.TabPages.Add($tabPlay)
$tabControl.TabPages.Add($tabAdv)
$tabControl.TabPages.Add($tabInfo)

# --- TAB: GIOCA ---
$lblPlatform = New-Object System.Windows.Forms.Label
$lblPlatform.Location = New-Object System.Drawing.Point(20, 20)
$lblPlatform.Size = New-Object System.Drawing.Size(200, 20)
$tabPlay.Controls.Add($lblPlatform)

# CORREZIONE 1: Combo Semplificata
$platformCombo = New-Object System.Windows.Forms.ComboBox
$platformCombo.Location = New-Object System.Drawing.Point(20, 45)
$platformCombo.Size = New-Object System.Drawing.Size(200, 25)
$platformCombo.DropDownStyle = "DropDownList"
$platformCombo.Items.Add("Auto-Detect / Manual")
$platformCombo.SelectedIndex = 0
$platformCombo.Enabled = $false # Bloccato come richiesto, solo Auto-Detect visibile
$tabPlay.Controls.Add($platformCombo)

$lblPath = New-Object System.Windows.Forms.Label
$lblPath.Location = New-Object System.Drawing.Point(20, 80)
$lblPath.Size = New-Object System.Drawing.Size(200, 20)
$tabPlay.Controls.Add($lblPath)

$pathTextBox = New-Object System.Windows.Forms.TextBox
$pathTextBox.Location = New-Object System.Drawing.Point(20, 105)
$pathTextBox.Size = New-Object System.Drawing.Size(400, 25)
$pathTextBox.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 60)
$pathTextBox.ForeColor = [System.Drawing.Color]::White
$tabPlay.Controls.Add($pathTextBox)

$browseBtn = New-Object System.Windows.Forms.Button
$browseBtn.Location = New-Object System.Drawing.Point(430, 103)
$browseBtn.Size = New-Object System.Drawing.Size(75, 25)
$browseBtn.FlatStyle = "Flat"
$browseBtn.ForeColor = [System.Drawing.Color]::White
$browseBtn.BackColor = [System.Drawing.Color]::FromArgb(70, 70, 70)
$tabPlay.Controls.Add($browseBtn)

# GRUPPO VIDEO
$grpVideo = New-Object System.Windows.Forms.GroupBox
$grpVideo.Location = New-Object System.Drawing.Point(20, 150)
$grpVideo.Size = New-Object System.Drawing.Size(485, 140)
$grpVideo.ForeColor = [System.Drawing.Color]::White
$grpVideo.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 50)
$tabPlay.Controls.Add($grpVideo)

$dx11Check = New-Object System.Windows.Forms.CheckBox
$dx11Check.Location = New-Object System.Drawing.Point(20, 30)
$dx11Check.Size = New-Object System.Drawing.Size(200, 20)
$grpVideo.Controls.Add($dx11Check)

$windowCheck = New-Object System.Windows.Forms.CheckBox
$windowCheck.Location = New-Object System.Drawing.Point(20, 60)
$windowCheck.Size = New-Object System.Drawing.Size(200, 20)
$grpVideo.Controls.Add($windowCheck)

$prioCheck = New-Object System.Windows.Forms.CheckBox
$prioCheck.Location = New-Object System.Drawing.Point(20, 90)
$prioCheck.Size = New-Object System.Drawing.Size(250, 20)
$prioCheck.ForeColor = [System.Drawing.Color]::LightGoldenrodYellow
$grpVideo.Controls.Add($prioCheck)

$lblDisplay = New-Object System.Windows.Forms.Label
$lblDisplay.Location = New-Object System.Drawing.Point(250, 30)
$lblDisplay.Size = New-Object System.Drawing.Size(200, 20)
$grpVideo.Controls.Add($lblDisplay)

$vrCombo = New-Object System.Windows.Forms.ComboBox
$vrCombo.Location = New-Object System.Drawing.Point(250, 55)
$vrCombo.Size = New-Object System.Drawing.Size(200, 25)
$vrCombo.DropDownStyle = "DropDownList"
$vrCombo.Items.AddRange(@("Monitor", "SteamVR", "Oculus"))
$vrCombo.SelectedIndex = 0
$grpVideo.Controls.Add($vrCombo)

# PULSANTE AVVIO
$launchBtn = New-Object System.Windows.Forms.Button
$launchBtn.Location = New-Object System.Drawing.Point(130, 310)
$launchBtn.Size = New-Object System.Drawing.Size(260, 50)
$launchBtn.BackColor = [System.Drawing.Color]::FromArgb(200, 80, 0)
$launchBtn.ForeColor = [System.Drawing.Color]::White
$launchBtn.Font = New-Object System.Drawing.Font("Arial", 12, [System.Drawing.FontStyle]::Bold)
$launchBtn.FlatStyle = "Flat"
$launchBtn.Cursor = [System.Windows.Forms.Cursors]::Hand
$tabPlay.Controls.Add($launchBtn)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Location = New-Object System.Drawing.Point(20, 380)
$statusLabel.Size = New-Object System.Drawing.Size(485, 25)
$statusLabel.TextAlign = "MiddleCenter"
$statusLabel.Font = New-Object System.Drawing.Font("Arial", 10, [System.Drawing.FontStyle]::Bold)
$tabPlay.Controls.Add($statusLabel)

# --- TAB: AVANZATE ---
$lblArgs = New-Object System.Windows.Forms.Label
$lblArgs.Location = New-Object System.Drawing.Point(20, 20)
$lblArgs.Size = New-Object System.Drawing.Size(300, 20)
$tabAdv.Controls.Add($lblArgs)

$argsBox = New-Object System.Windows.Forms.TextBox
$argsBox.Location = New-Object System.Drawing.Point(20, 45)
$argsBox.Size = New-Object System.Drawing.Size(485, 25)
$argsBox.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 60)
$argsBox.ForeColor = [System.Drawing.Color]::White
$tabAdv.Controls.Add($argsBox)

$closeCheck = New-Object System.Windows.Forms.CheckBox
$closeCheck.Location = New-Object System.Drawing.Point(20, 90)
$closeCheck.Size = New-Object System.Drawing.Size(400, 20)
$closeCheck.ForeColor = [System.Drawing.Color]::White
$tabAdv.Controls.Add($closeCheck)

$grpPanic = New-Object System.Windows.Forms.GroupBox
$grpPanic.Location = New-Object System.Drawing.Point(20, 140)
$grpPanic.Size = New-Object System.Drawing.Size(485, 160)
$grpPanic.ForeColor = [System.Drawing.Color]::White
$grpPanic.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 50)
$tabAdv.Controls.Add($grpPanic)

$btnReShade = New-Object System.Windows.Forms.Button
$btnReShade.Location = New-Object System.Drawing.Point(20, 30)
$btnReShade.Size = New-Object System.Drawing.Size(445, 35)
$btnReShade.FlatStyle = "Flat"
$btnReShade.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 60)
$btnReShade.ForeColor = [System.Drawing.Color]::White
$grpPanic.Controls.Add($btnReShade)

$btnCleanCache = New-Object System.Windows.Forms.Button
$btnCleanCache.Location = New-Object System.Drawing.Point(20, 80)
$btnCleanCache.Size = New-Object System.Drawing.Size(445, 40)
$btnCleanCache.BackColor = [System.Drawing.Color]::DarkRed
$btnCleanCache.ForeColor = [System.Drawing.Color]::White
$btnCleanCache.FlatStyle = "Flat"
$btnCleanCache.Font = New-Object System.Drawing.Font("Arial", 10, [System.Drawing.FontStyle]::Bold)
$grpPanic.Controls.Add($btnCleanCache)

# --- TAB: INFO ---
$btnLogs = New-Object System.Windows.Forms.Button
$btnLogs.Location = New-Object System.Drawing.Point(30, 40)
$btnLogs.Size = New-Object System.Drawing.Size(200, 35)
$btnLogs.FlatStyle = "Flat"
$btnLogs.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 70)
$btnLogs.ForeColor = [System.Drawing.Color]::White
$tabInfo.Controls.Add($btnLogs)

$btnMods = New-Object System.Windows.Forms.Button
$btnMods.Location = New-Object System.Drawing.Point(30, 90)
$btnMods.Size = New-Object System.Drawing.Size(200, 35)
$btnMods.FlatStyle = "Flat"
$btnMods.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 70)
$btnMods.ForeColor = [System.Drawing.Color]::White
$tabInfo.Controls.Add($btnMods)

$linkWeb = New-Object System.Windows.Forms.LinkLabel
$linkWeb.Location = New-Object System.Drawing.Point(30, 150)
$linkWeb.Size = New-Object System.Drawing.Size(300, 25)
$linkWeb.LinkColor = [System.Drawing.Color]::LightSkyBlue
$linkWeb.ActiveLinkColor = [System.Drawing.Color]::Cyan
$tabInfo.Controls.Add($linkWeb)

$form.Add_FormClosing({ Save-Config })

# ==========================================
# 4. FUNZIONI DI LOGICA AGGIORNATA
# ==========================================

function Update-UI {
    $T = $langDict[$global:currentLang]
    
    $form.Text = $T.Title
    $titleLabel.Text = $T.Title
    $tabPlay.Text = $T.TabPlay
    $tabAdv.Text = $T.TabAdv
    $tabInfo.Text = $T.TabInfo
    
    $lblPlatform.Text = $T.Platform
    $lblPath.Text = $T.Path
    $browseBtn.Text = $T.Browse
    $launchBtn.Text = $T.Launch
    $grpVideo.Text = $T.VideoOpt
    $dx11Check.Text = $T.ForceDX11
    $windowCheck.Text = $T.Windowed
    $prioCheck.Text = $T.HighPrio
    $lblDisplay.Text = $T.DisplayMode
    
    $lblArgs.Text = $T.CustomArgs
    $closeCheck.Text = $T.CloseLauncher
    $grpPanic.Text = $T.Maintenance
    $btnCleanCache.Text = $T.ClearCache
    
    $btnLogs.Text = $T.OpenLogs
    $btnMods.Text = $T.OpenMods
    $linkWeb.Text = $T.WebSite

    $sel = $vrCombo.SelectedIndex
    $vrCombo.Items.Clear()
    $vrCombo.Items.Add($T.Monitor)
    $vrCombo.Items.Add($T.OpenVR)
    $vrCombo.Items.Add($T.Oculus)
    if ($sel -ge 0 -and $sel -lt $vrCombo.Items.Count) { $vrCombo.SelectedIndex = $sel } else { $vrCombo.SelectedIndex = 0 }

    $statusLabel.Text = $T[$global:currentStatusKey]
    switch ($global:currentStatusKey) {
        "StatusReady" { $statusLabel.ForeColor = [System.Drawing.Color]::LightGreen }
        "StatusErr"   { $statusLabel.ForeColor = [System.Drawing.Color]::Red }
        "StatusSearch"{ $statusLabel.ForeColor = [System.Drawing.Color]::Yellow }
        "StatusManual"{ $statusLabel.ForeColor = [System.Drawing.Color]::Cyan }
        Default       { $statusLabel.ForeColor = [System.Drawing.Color]::White }
    }

    # ReShade UI Logic
    $currentPath = $pathTextBox.Text
    $btnReShade.Text = $T.ReShadeNo
    $btnReShade.ForeColor = [System.Drawing.Color]::Gray
    $btnReShade.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 60)

    if (-not [string]::IsNullOrWhiteSpace($currentPath) -and (Test-Path $currentPath)) {
        $dir = [System.IO.Path]::GetDirectoryName($currentPath)
        if (Test-Path "$dir\dxgi.dll") {
            $btnReShade.Text = $T.ReShadeOn
            $btnReShade.ForeColor = [System.Drawing.Color]::LightGreen
            $btnReShade.BackColor = [System.Drawing.Color]::FromArgb(30, 60, 30)
        } elseif (Test-Path "$dir\dxgi.dll.off") {
            $btnReShade.Text = $T.ReShadeOff
            $btnReShade.ForeColor = [System.Drawing.Color]::Orange
            $btnReShade.BackColor = [System.Drawing.Color]::FromArgb(60, 40, 10)
        }
    }
    $form.Refresh()
}

$langButton.add_Click({
    if ($global:currentLang -eq "IT") { $global:currentLang = "EN" } else { $global:currentLang = "IT" }
    Update-UI
})

function Find-Game {
    $T = $langDict[$global:currentLang]
    $global:currentStatusKey = "StatusSearch"
    Update-UI
    
    # Lista di percorsi comuni espansa per "Scansione Approfondita"
    $searchPaths = @(
        "C:\Program Files (x86)\Steam\steamapps\common\Assetto Corsa Rally\acr\Binaries\Win64\acr.exe",
        "C:\Program Files\Steam\steamapps\common\Assetto Corsa Rally\acr\Binaries\Win64\acr.exe",
        "D:\SteamLibrary\steamapps\common\Assetto Corsa Rally\acr\Binaries\Win64\acr.exe",
        "D:\Games\Steam\steamapps\common\Assetto Corsa Rally\acr\Binaries\Win64\acr.exe",
        "E:\SteamLibrary\steamapps\common\Assetto Corsa Rally\acr\Binaries\Win64\acr.exe",
        "F:\SteamLibrary\steamapps\common\Assetto Corsa Rally\acr\Binaries\Win64\acr.exe",
        "C:\Program Files\Epic Games\AssettoCorsaRally\acr\Binaries\Win64\acr.exe",
        "D:\Epic Games\AssettoCorsaRally\acr\Binaries\Win64\acr.exe"
    )

    $found = $false
    
    # 1. Scansione rapida percorsi noti
    foreach ($p in $searchPaths) {
        # Evita il freeze GUI
        [System.Windows.Forms.Application]::DoEvents()
        
        if (Test-Path $p) {
            $pathTextBox.Text = $p
            $global:currentStatusKey = "StatusReady"
            $found = $true
            try { $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($p) } catch {}
            break
        }
    }

    # 2. Se non trovato e non è stato impostato manuale, chiedi di scaricare
    if (-not $found) { 
        $pathTextBox.Text = ""
        $global:currentStatusKey = "StatusErr"
        
        $res = [System.Windows.Forms.MessageBox]::Show(
            $T.MissingMsg, 
            "Assetto Corsa Rally", 
            [System.Windows.Forms.MessageBoxButtons]::YesNo, 
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        
        if ($res -eq "Yes") {
            Start-Process "https://assettocorsa.gg/assetto-corsa-rally/"
        }
    }
    Update-UI 
}

$browseBtn.add_Click({
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = "ACR Executable (acr.exe)|acr.exe"
    $ofd.Title = "Select acr.exe"
    if ($ofd.ShowDialog() -eq "OK") {
        $pathTextBox.Text = $ofd.FileName
        $global:currentStatusKey = "StatusManual"
        Update-UI
        try { $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($ofd.FileName) } catch {}
    }
})

# --- EVENTI PULSANTI AVANZATI ---
$btnReShade.add_Click({
    $currentPath = $pathTextBox.Text
    if (-not [string]::IsNullOrWhiteSpace($currentPath)) {
        $dir = [System.IO.Path]::GetDirectoryName($currentPath)
        $on = "$dir\dxgi.dll"
        $off = "$dir\dxgi.dll.off"
        if (Test-Path $on) { Rename-Item $on "dxgi.dll.off" } elseif (Test-Path $off) { Rename-Item $off "dxgi.dll" }
        Update-UI 
    }
})

$btnCleanCache.add_Click({
    $T = $langDict[$global:currentLang]
    $res = [System.Windows.Forms.MessageBox]::Show($T.CleanConfirm, "Warning", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
    
    if ($res -eq "Yes") {
        # CORREZIONE 2: Percorso UE4/UE5 corretto
        if (Test-Path $global:gameConfigDir) {
            try {
                Get-ChildItem -Path $global:gameConfigDir -Filter "*.ini" | Remove-Item -Force
                [System.Windows.Forms.MessageBox]::Show("Cache (ini) pulita.", "Success")
            } catch {
                [System.Windows.Forms.MessageBox]::Show("Errore: $_", "Error")
            }
        } else {
             [System.Windows.Forms.MessageBox]::Show("Cartella Config non trovata ($global:gameConfigDir).", "Info")
        }
    }
})

$launchBtn.add_Click({
    $exe = $pathTextBox.Text
    $T = $langDict[$global:currentLang]
    
    if ([string]::IsNullOrWhiteSpace($exe) -or -not (Test-Path $exe)) {
        $global:currentStatusKey = "StatusErr"
        Update-UI
        [System.Windows.Forms.MessageBox]::Show($T.StatusErr, "Error", 0, 16)
        return
    }
    
    $procName = [System.IO.Path]::GetFileNameWithoutExtension($exe)
    if (Get-Process -Name $procName -ErrorAction SilentlyContinue) {
        [System.Windows.Forms.MessageBox]::Show($T.RunningWarn, "Warning", 0, 48)
        return
    }

    Save-Config
    
    $argsList = @()
    if ($dx11Check.Checked) { $argsList += "-dx11" }
    if ($windowCheck.Checked) { $argsList += "-windowed" }
    switch ($vrCombo.SelectedIndex) {
        1 { $argsList += "-openvr"; $argsList += "-vr" }
        2 { $argsList += "-oculus"; $argsList += "-vr" }
    }
    if (-not [string]::IsNullOrWhiteSpace($argsBox.Text)) { 
        $argsList += ($argsBox.Text.Trim() -split '\s+')
    }

    try {
        $global:currentStatusKey = "StatusRun"
        Update-UI
        
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $exe
        $psi.Arguments = $argsList -join " "
        $psi.WorkingDirectory = [System.IO.Path]::GetDirectoryName($exe)
        $psi.UseShellExecute = $true # UseShellExecute true spesso risolve problemi di permessi/path

        Write-Host "Avvio: $exe $($psi.Arguments)"
        $proc = [System.Diagnostics.Process]::Start($psi)
        
        # CORREZIONE 3: Gestione sicura Priorità
        if ($prioCheck.Checked -and $proc -ne $null) {
            # Aspetta che il processo si stabilizzi
            Start-Sleep -Milliseconds 2000 
            
            try {
                if (-not $proc.HasExited) {
                    $proc.PriorityClass = [System.Diagnostics.ProcessPriorityClass]::High 
                    Write-Host "Priorità impostata a High per PID $($proc.Id)"
                } else {
                    Write-Host "Processo terminato prima dell'impostazione priorità (Normale per alcuni wrapper)"
                }
            } catch {
                Write-Host "Warning: Impossibile impostare priorità (Access Denied o Exited)"
            }
        }

        if ($closeCheck.Checked) { 
            Start-Sleep -Milliseconds 1000
            $form.Close() 
        } else {
            Start-Sleep -Seconds 3
            if (-not (Get-Process -Name $procName -ErrorAction SilentlyContinue)) {
                $global:currentStatusKey = "StatusReady"
                Update-UI
            }
        }
    } catch {
        $global:currentStatusKey = "StatusErr"
        Update-UI
        [System.Windows.Forms.MessageBox]::Show("Error launching game:`n$($_.Exception.Message)", "Error", 0, 16)
    }
})

$linkWeb.add_Click({ Start-Process "https://assettocorsa.gg/assetto-corsa-rally/" })

$btnLogs.add_Click({ 
    $logPath = "$env:LOCALAPPDATA\acr\Saved\Logs"
    if (-not (Test-Path $logPath)) { New-Item -ItemType Directory -Force -Path $logPath | Out-Null }
    Invoke-Item $logPath 
})

$btnMods.add_Click({ 
    $currentPath = $pathTextBox.Text
    if (-not [string]::IsNullOrWhiteSpace($currentPath) -and (Test-Path $currentPath)) {
        $gameDir = Split-Path $currentPath -Parent
        $modsPath = Join-Path $gameDir "mods"
        if (-not (Test-Path $modsPath)) { $modsPath = Join-Path $gameDir "content" }
        if (Test-Path $modsPath) { Invoke-Item $modsPath } else { Invoke-Item $gameDir }
    } else {
        [System.Windows.Forms.MessageBox]::Show("Configura prima il percorso del gioco.", "Info")
    }
})

# ==========================================
# 5. CARICAMENTO CONFIGURAZIONE E AVVIO
# ==========================================
$savedConfig = Get-Config
if ($savedConfig) {
    if ($savedConfig.Path) { $pathTextBox.Text = $savedConfig.Path }
    if ($savedConfig.DX11 -ne $null) { $dx11Check.Checked = $savedConfig.DX11 }
    if ($savedConfig.Windowed -ne $null) { $windowCheck.Checked = $savedConfig.Windowed }
    if ($savedConfig.HighPrio -ne $null) { $prioCheck.Checked = $savedConfig.HighPrio }
    if ($savedConfig.VRMode -ne $null -and $savedConfig.VRMode -lt $vrCombo.Items.Count) { $vrCombo.SelectedIndex = $savedConfig.VRMode }
    if ($savedConfig.CloseOnStart -ne $null) { $closeCheck.Checked = $savedConfig.CloseOnStart }
    if ($savedConfig.CustomArgs) { $argsBox.Text = $savedConfig.CustomArgs }
    if ($savedConfig.Language) { $global:currentLang = $savedConfig.Language }
}

# Auto-Detect all'avvio se vuoto
if ([string]::IsNullOrWhiteSpace($pathTextBox.Text)) {
    Find-Game
} elseif (Test-Path $pathTextBox.Text) {
    $global:currentStatusKey = "StatusReady"
    try { $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($pathTextBox.Text) } catch {}
} else {
    Find-Game
}

Update-UI
[void]$form.ShowDialog()