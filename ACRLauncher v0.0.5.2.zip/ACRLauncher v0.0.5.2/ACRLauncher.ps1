<#
    ACR Launcher v0.0.5.2 - Ultimate Edition (UI Fix)
    
    Changelog:
    1. UI Layout Fix: Game Booster labels no longer overlap (moved to new line).
    2. Bug Fix: Info Tab buttons now show text correctly (missing strings added).
#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem

# ==========================================
# 0. VARIABILI GLOBALI & URL UPDATE
# ==========================================
$global:LauncherVersion = "5.2"
$global:UpdateUrl = "" 

# ==========================================
# 1. GESTIONE LINGUA E TESTI
# ==========================================
$langDict = @{
    "IT" = @{
        "Title" = "Assetto Corsa Rally - Launcher v$global:LauncherVersion";
        "TabPlay" = "  Gioca  ";
        "TabAdv" = "  Avanzate  ";
        "TabInfo" = "  Info  ";
        
        "Platform" = "Metodo Rilevamento:";
        "Path" = "Percorso Eseguibile (acr.exe):";
        "Browse" = "Sfoglia...";
        "Launch" = "AVVIA MOTORE";
        
        "VideoOpt" = "Opzioni Video & Performance";
        "ForceDX11" = "Forza DirectX 11 (-dx11)";
        "Windowed" = "Modalità Finestra (-windowed)";
        "HighPrio" = "Boost Priorità CPU (High)";
        "Affinity" = "Affinità: Solo Core Fisici (No-SMT)";
        "DisplayMode" = "Modalità Visualizzazione:";
        "Monitor" = "Monitor Standard";
        "OpenVR" = "SteamVR (OpenVR)";
        "Oculus" = "Oculus VR";
        
        "CloseLauncher" = "Chiudi launcher all'avvio";
        "CustomArgs" = "Argomenti extra:";
        
        "Maintenance" = "Manutenzione & Salvataggi";
        "BackupTitle" = "Gestione Salvataggi (Backup/Restore)";
        "BtnBackup" = "CREA BACKUP ORA";
        "BtnRestore" = "RIPRISTINA ULTIMO BACKUP";
        "BackupMsg" = "Backup creato in:";
        "RestoreMsg" = "Ultimo backup ripristinato con successo!";
        "NoBackup" = "Nessun backup trovato.";
        
        "BoosterTitle" = "Game Booster (App Background)";
        "BoosterCheck" = "Attiva Game Booster all'avvio";
        "BoosterList" = "App da chiudere (separate da virgola):";
        "BoosterDefault" = "chrome,msedge,teams,discord";
        
        "IniEdit" = "Modifica Config (.ini)";
        "ClearCache" = "PANIC BUTTON: Pulisci Cache";
        "CleanConfirm" = "ATTENZIONE: Questo cancellerà le impostazioni video (GameUserSettings.ini). Continuare?";
        
        "ReShadeOn" = "ReShade: ATTIVO (Disabilita)";
        "ReShadeOff" = "ReShade: DISATTIVO (Abilita)";
        "ReShadeNo" = "ReShade non installato (dxgi.dll)";
        
        "RunningWarn" = "Il gioco è già in esecuzione!";
        "MissingMsg" = "Eseguibile acr.exe non trovato!`n`nVuoi scaricarlo?";
        
        "StatusReady" = "Pronto alla partenza";
        "StatusSearch" = "Ricerca eseguibile in corso...";
        "StatusErr" = "Errore: Eseguibile non trovato";
        "StatusRun" = "Gioco in esecuzione...";
        "StatusManual" = "Percorso manuale selezionato";
        
        # FIX: Aggiunte chiavi mancanti per TAB INFO
        "OpenLogs" = "Apri Cartella Log";
        "OpenMods" = "Apri Cartella Mods";
        "WebSite" = "Sito Ufficiale"
    };
    "EN" = @{
        "Title" = "Assetto Corsa Rally - Launcher v$global:LauncherVersion";
        "TabPlay" = "  Play  ";
        "TabAdv" = "  Advanced  ";
        "TabInfo" = "  Info  ";
        
        "Platform" = "Detection Method:";
        "Path" = "Executable Path (acr.exe):";
        "Browse" = "Browse...";
        "Launch" = "START ENGINE";
        
        "VideoOpt" = "Video & Performance Options";
        "ForceDX11" = "Force DirectX 11 (-dx11)";
        "Windowed" = "Windowed Mode (-windowed)";
        "HighPrio" = "CPU Priority Boost (High)";
        "Affinity" = "Affinity: Physical Cores Only (No-SMT)";
        "DisplayMode" = "Display Mode:";
        "Monitor" = "Standard Monitor";
        "OpenVR" = "SteamVR (OpenVR)";
        "Oculus" = "Oculus VR";
        
        "CloseLauncher" = "Close launcher on start";
        "CustomArgs" = "Extra Arguments:";
        
        "Maintenance" = "Maintenance & Saves";
        "BackupTitle" = "Save Manager (Backup/Restore)";
        "BtnBackup" = "CREATE BACKUP NOW";
        "BtnRestore" = "RESTORE LATEST BACKUP";
        "BackupMsg" = "Backup created at:";
        "RestoreMsg" = "Latest backup restored successfully!";
        "NoBackup" = "No backups found.";
        
        "BoosterTitle" = "Game Booster (Background Apps)";
        "BoosterCheck" = "Enable Game Booster on Launch";
        "BoosterList" = "Apps to kill (comma separated):";
        "BoosterDefault" = "chrome,msedge,teams,discord";
        
        "IniEdit" = "Edit Config (.ini)";
        "ClearCache" = "PANIC BUTTON: Clear Cache";
        "CleanConfirm" = "WARNING: This will wipe video settings. Continue?";
        
        "ReShadeOn" = "ReShade: ACTIVE (Disable)";
        "ReShadeOff" = "ReShade: DISABLED (Enable)";
        "ReShadeNo" = "ReShade not found (dxgi.dll)";
        
        "RunningWarn" = "Game is already running!";
        "MissingMsg" = "Executable acr.exe not found!`n`nDownload it?";
        
        "StatusReady" = "Ready to race";
        "StatusSearch" = "Searching executable...";
        "StatusErr" = "Error: Executable missing";
        "StatusRun" = "Game is running...";
        "StatusManual" = "Manual path selected";
        
        # FIX: Added missing keys for INFO TAB
        "OpenLogs" = "Open Logs Folder";
        "OpenMods" = "Open Mods Folder";
        "WebSite" = "Official Website"
    }
}

$global:currentLang = "IT"
$global:currentStatusKey = "StatusSearch"
# Percorso corretto UE4/UE5 per ACR
$global:gameConfigDir = "$env:LOCALAPPDATA\acr\Saved\Config\Windows"
$global:saveDir = "$env:LOCALAPPDATA\acr\Saved"

# ==========================================
# 2. CONFIGURAZIONE
# ==========================================
$appDataDir = Join-Path $env:APPDATA "ACRLauncher"
$backupDir = Join-Path $appDataDir "Backups"

if (-not (Test-Path $appDataDir)) { New-Item -ItemType Directory -Path $appDataDir -Force | Out-Null }
if (-not (Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }

$configFile = Join-Path $appDataDir "acr_config.json"

function Get-Config {
    if (Test-Path $configFile) {
        try {
            $json = [System.IO.File]::ReadAllText($configFile, [System.Text.Encoding]::UTF8)
            return $json | ConvertFrom-Json
        }
        catch { return $null }
    }
    return $null
}

function Save-Config {
    try {
        $config = @{
            Path        = $pathTextBox.Text
            DX11        = $dx11Check.Checked
            Windowed    = $windowCheck.Checked
            HighPrio    = $prioCheck.Checked
            Affinity    = $affinityCheck.Checked
            VRMode      = $vrCombo.SelectedIndex
            CloseOnStart= $closeCheck.Checked
            CustomArgs  = $argsBox.Text
            Language    = $global:currentLang
            BoosterEnabled = $boosterCheck.Checked
            BoosterApps = $boosterBox.Text
        }
        $json = $config | ConvertTo-Json -Depth 3
        [System.IO.File]::WriteAllText($configFile, $json, [System.Text.Encoding]::UTF8)
    }
    catch {
        Write-Host "Errore salvataggio config: $_"
    }
}

# ==========================================
# 3. INTERFACCIA GRAFICA (GUI)
# ==========================================
$form = New-Object System.Windows.Forms.Form
$form.Text = "Assetto Corsa Rally - Launcher v$global:LauncherVersion"
$form.Size = New-Object System.Drawing.Size(550, 680)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(32, 32, 32)
$form.ForeColor = [System.Drawing.Color]::White

# --- EMBEDDED ICON (BASE64) ---
try {
    $iconBase64 = "AAABAAEAICAAAAEACACoCAAAFgAAACgAAAAgAAAAQAAAAAEACAAAAAAAAAQAAAAAAAAAAAAAAAEAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFRUVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANDQ0AAAAAAAIKGQABBQ0ABRg4AAIKGQAAAwYA////AAAAAABZWlkAWFlYAFRUVAA+QD8AIyQjADc5OABpcG8ASktLADU2NgBeYmEAQUJCADEyMQA5OjoAV1hXAAIDAwBFRkYATE1MAAwMDABISUgADxAQAPX19QBhZGMAGhwcAGZoZwBzd3UABiFBACorKwBCRUUALi8vAAei/gAXb/8AbnJxAAA6tACSm5kAPD08AB0eHgABc7MA7u7uADQ1NAAgICAAfIKBAISOjAAIEi4ABwkJABgZGAAGH0gAAhInAAJqoAAMlf8ABB08ABNf1wADMFEAFHr/AAFPdQAPif8AGG3/AAqZ/wAAMJAAAAF9AABqwwAAldYAAG/IAABDtABaWvMA2Nj8AABQvAB1e3kApqamAACl3AAAsuEAq6v5AOHh4QDPz88AAEeJAAAmkwAVFe4A1dXVAADD6AD8/P4AAgLtAEZKSQAAn9cAg4aFAE5PTgAGQm8AWF5dAAM7VwAFd8oABT18AAGv9QAEgtEAC16xACYnJwARhf8AElLCAAAWIAALNn0AAQwSAAgkVQASZd0AAj5gAAouawALMXUAAi5JABCA8wAOcdoAFWDfABJv6gANkP8AFnL/AAUXNgASgP8ADo3+AACK0gAAfc0AAF7BAABBngAADXgAurq6AO/v/QAQFEkAqLWyAMLCwgAAMK8AAANEAAAjewA2QUQAoa2qAAB5pgCcnPgAAF/BACo5PwARO00AAH+sABFKrgAAcZMAZ2ppAAAQOgAAKJoAAHKaACpGTADGxsYAAH+HANra2gARQUcAI0hPAFtbWwA1NfAAArT/AK+vrwCOjvMA6ur9AH19fQCenp4AAM3rAACPngAAV2UAALLHAACZwgAVdv8AAKjdAA9TtQACGB8Ar6/WAAczOwAAq8MAA1xiAOjo6ADOzs4ATVBPAAdcnwADDR4AF2buAA49kAAJKmMAAUNjAARCawAYafYAAic3AAppuwANOYUADEWUAAVZkQAFf8UAB2OmAAGKwAAGqP8AFFjPABR19gAFM1wADm3RAAmP6wAIXqIACZv4AARwqwAJP4AABar/AAJhjwAFKE8ABkR3AAZurwAEnOUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkVBQoABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJFRELFAcHCwAYGAMJAAAAAAAAAAAAAAAAAAAAAAQRCxIHHiEMCAYFAwsHBxoREwAAAAAAAAAAAAAAAwoSBwcBKQ4knJRgARIHGygdHgcSBSYAAAAAAAAAAAAKAiguD2fj8aRtbWAXAgYHHeEwDBcHFAoEAAAAAAAABQoZY7xk4m2gY1SjpAgqNQgi5OfqMichBwcYFgAAACAiFynX1WTyaqFnpaX8NUdJRCtjVKCcaJsIIh4bAAAADesxCJGTT59spmSmov1cNkFIOk9qoZttbZiWLxAAAAAjnpmY4GaK7m5unZBT/jo2QUZIaWz0+WqjlmiUHyYAACyNZzVrU1qa8Ppla//7RzhBPVLsbvaRbJOOaJkOBAAAAWlEUOjKj5WP72tJkkBDNkFIXZ3tmvVmovOenw4RAAAVJDVGYrvB2ExBPTc3PT5cOztAOUmX+FP3aWbpDgsAAAAsYU7fOlg4NkNAQjtRQzc7PYk+QEVilYxlU+Y1FwAAAA1SX15VNzk5OTg2NjdYYLJPPjdGQVE4OpflYUchAAAWKz9ePz1GNzY2NkNCrnBwq7N/ujk3PVJFPz5ATB0AAAI1WT9NTUtLP0a5iqpvb3RWsYB/vcZCQ0hQRTxQDAAAFgwqYTlOeE470dRaWo1zcal3dFaAZcRCNjZFkkwOAAAAJg1dNUdGiIbSh9Z6h3KnqHO4d1bAv0C+TThMNQ0AAAAQHH15WTVJizba29CDe3pykHGOTzk8XjxSRDUnAwAAJg9V3jRKiEc1YotR3NODe7aMtFVXV3g+RDUPAQkAAAAbQjQ0NDQ03U1ENV08S8fCPLWvVz86NTUlHQQAAAAAACBFgjQ0NITJgdk4NTVQX188hlk1NTUIBgQAAAAAAAAABjp5NDQ0rYWFfDTeiTU1NTU1NQ8ZGgkAAAAAAAAAAAACODQ0NDR2gbeENDQ0xcgjEAIFAAAAAAAAAAAAAAAAAAMcfls0NHV8NDQ0NDTDNwEAAAAAAAAAAAAAAAAAAAAAAB9JsDR2dTQ0NDQ0W5IlFQAAAAAAAAAAAAAAAAAAAAAABS2CSszNNDQ0NEpKPiAAAAAAAAAAAAAAAAAAAAAAAAAAAhw4TjRbfTSsXEIZAAAAAAAAAAAAAAAAAAAAAAAAAAAAGghYz849y0skBgkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJgIMIw0fBhYAAAAAAAAAAAAAAAAAAAAAAAAAAP////////////C///8Ah//4AAH/wAAAf8AAAB+AAAAHAAAABwAAAAcAAAADAAAAAwAAAAMAAAADgAAAA4AAAAMAAAADAAAAAwAAAAOAAAADgAAAAwAAAAcAAAAfAAAAfwAAAf8AAB//AAD//4AA//+AAf//wAP//+AD///wD///" 

    if (-not [string]::IsNullOrEmpty($iconBase64)) {
        $iconBytes = [System.Convert]::FromBase64String($iconBase64)
        $iconStream = New-Object System.IO.MemoryStream($iconBytes, 0, $iconBytes.Length)
        $form.Icon = New-Object System.Drawing.Icon($iconStream)
    }
}
catch {
    Write-Host "Icon load warning: $($_.Exception.Message)" -ForegroundColor Yellow
}
# ----------------------------------

# --- Header ---
$headerPanel = New-Object System.Windows.Forms.Panel
$headerPanel.Size = New-Object System.Drawing.Size(550, 50)
$headerPanel.Dock = "Top"
$headerPanel.BackColor = [System.Drawing.Color]::FromArgb(45, 45, 48)
$form.Controls.Add($headerPanel)

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$titleLabel.ForeColor = [System.Drawing.Color]::Orange
$titleLabel.Location = New-Object System.Drawing.Point(10, 15)
$titleLabel.Size = New-Object System.Drawing.Size(350, 30)
$headerPanel.Controls.Add($titleLabel)

$langButton = New-Object System.Windows.Forms.Button
$langButton.Text = "IT / EN"
$langButton.Location = New-Object System.Drawing.Point(440, 10)
$langButton.Size = New-Object System.Drawing.Size(80, 30)
$langButton.FlatStyle = "Flat"
$langButton.ForeColor = [System.Drawing.Color]::White
$langButton.BackColor = [System.Drawing.Color]::FromArgb(60,60,60)
$headerPanel.Controls.Add($langButton)

# --- Tab Control ---
$tabControl = New-Object System.Windows.Forms.TabControl
$tabControl.Location = New-Object System.Drawing.Point(0, 50)
$tabControl.Size = New-Object System.Drawing.Size(550, 600)
$tabControl.Padding = New-Object System.Drawing.Point(10, 6)
$tabControl.Appearance = "Normal"
$tabControl.BackColor = [System.Drawing.Color]::FromArgb(45, 45, 48)
$tabControl.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($tabControl)

$tabPlay = New-Object System.Windows.Forms.TabPage; $tabPlay.Name="tabPlay"; $tabPlay.BackColor=[System.Drawing.Color]::FromArgb(40,40,40)
$tabAdv = New-Object System.Windows.Forms.TabPage; $tabAdv.Name="tabAdv"; $tabAdv.BackColor=[System.Drawing.Color]::FromArgb(40,40,40)
$tabInfo = New-Object System.Windows.Forms.TabPage; $tabInfo.Name="tabInfo"; $tabInfo.BackColor=[System.Drawing.Color]::FromArgb(40,40,40)

$tabControl.TabPages.Add($tabPlay)
$tabControl.TabPages.Add($tabAdv)
$tabControl.TabPages.Add($tabInfo)

# --- TAB: GIOCA ---
$lblPlatform = New-Object System.Windows.Forms.Label
$lblPlatform.Location = New-Object System.Drawing.Point(20, 20)
$lblPlatform.Size = New-Object System.Drawing.Size(200, 20)
$tabPlay.Controls.Add($lblPlatform)

$platformCombo = New-Object System.Windows.Forms.ComboBox
$platformCombo.Location = New-Object System.Drawing.Point(20, 45)
$platformCombo.Size = New-Object System.Drawing.Size(200, 25)
$platformCombo.DropDownStyle = "DropDownList"
$platformCombo.Items.Add("Auto-Detect / Manual")
$platformCombo.SelectedIndex = 0
$platformCombo.Enabled = $false
$tabPlay.Controls.Add($platformCombo)

$lblPath = New-Object System.Windows.Forms.Label
$lblPath.Location = New-Object System.Drawing.Point(20, 80)
$lblPath.Size = New-Object System.Drawing.Size(200, 20)
$tabPlay.Controls.Add($lblPath)

$pathTextBox = New-Object System.Windows.Forms.TextBox
$pathTextBox.Location = New-Object System.Drawing.Point(20, 105)
$pathTextBox.Size = New-Object System.Drawing.Size(400, 25)
$pathTextBox.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 60)
$pathTextBox.ForeColor = [System.Drawing.Color]::White
$tabPlay.Controls.Add($pathTextBox)

$browseBtn = New-Object System.Windows.Forms.Button
$browseBtn.Location = New-Object System.Drawing.Point(430, 103)
$browseBtn.Size = New-Object System.Drawing.Size(75, 25)
$browseBtn.FlatStyle = "Flat"
$browseBtn.ForeColor = [System.Drawing.Color]::White
$browseBtn.BackColor = [System.Drawing.Color]::FromArgb(70, 70, 70)
$tabPlay.Controls.Add($browseBtn)

# GRUPPO VIDEO
$grpVideo = New-Object System.Windows.Forms.GroupBox
$grpVideo.Location = New-Object System.Drawing.Point(20, 150)
$grpVideo.Size = New-Object System.Drawing.Size(485, 160) 
$grpVideo.ForeColor = [System.Drawing.Color]::White
$grpVideo.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 50)
$tabPlay.Controls.Add($grpVideo)

$dx11Check = New-Object System.Windows.Forms.CheckBox
$dx11Check.Location = New-Object System.Drawing.Point(20, 30)
$dx11Check.Size = New-Object System.Drawing.Size(200, 20)
$grpVideo.Controls.Add($dx11Check)

$windowCheck = New-Object System.Windows.Forms.CheckBox
$windowCheck.Location = New-Object System.Drawing.Point(20, 60)
$windowCheck.Size = New-Object System.Drawing.Size(200, 20)
$grpVideo.Controls.Add($windowCheck)

$prioCheck = New-Object System.Windows.Forms.CheckBox
$prioCheck.Location = New-Object System.Drawing.Point(20, 90)
$prioCheck.Size = New-Object System.Drawing.Size(250, 20)
$prioCheck.ForeColor = [System.Drawing.Color]::LightGoldenrodYellow
$grpVideo.Controls.Add($prioCheck)

$affinityCheck = New-Object System.Windows.Forms.CheckBox
$affinityCheck.Location = New-Object System.Drawing.Point(20, 120)
$affinityCheck.Size = New-Object System.Drawing.Size(250, 20)
$affinityCheck.ForeColor = [System.Drawing.Color]::LightSkyBlue
$grpVideo.Controls.Add($affinityCheck)

$lblDisplay = New-Object System.Windows.Forms.Label
$lblDisplay.Location = New-Object System.Drawing.Point(250, 30)
$lblDisplay.Size = New-Object System.Drawing.Size(200, 20)
$grpVideo.Controls.Add($lblDisplay)

$vrCombo = New-Object System.Windows.Forms.ComboBox
$vrCombo.Location = New-Object System.Drawing.Point(250, 55)
$vrCombo.Size = New-Object System.Drawing.Size(200, 25)
$vrCombo.DropDownStyle = "DropDownList"
$vrCombo.Items.AddRange(@("Monitor", "SteamVR", "Oculus"))
$vrCombo.SelectedIndex = 0
$grpVideo.Controls.Add($vrCombo)

$launchBtn = New-Object System.Windows.Forms.Button
$launchBtn.Location = New-Object System.Drawing.Point(130, 330)
$launchBtn.Size = New-Object System.Drawing.Size(260, 50)
$launchBtn.BackColor = [System.Drawing.Color]::FromArgb(200, 80, 0)
$launchBtn.ForeColor = [System.Drawing.Color]::White
$launchBtn.Font = New-Object System.Drawing.Font("Arial", 12, [System.Drawing.FontStyle]::Bold)
$launchBtn.FlatStyle = "Flat"
$launchBtn.Cursor = [System.Windows.Forms.Cursors]::Hand
$tabPlay.Controls.Add($launchBtn)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Location = New-Object System.Drawing.Point(20, 400)
$statusLabel.Size = New-Object System.Drawing.Size(485, 25)
$statusLabel.TextAlign = "MiddleCenter"
$statusLabel.Font = New-Object System.Drawing.Font("Arial", 10, [System.Drawing.FontStyle]::Bold)
$tabPlay.Controls.Add($statusLabel)

# --- TAB: AVANZATE ---
$lblArgs = New-Object System.Windows.Forms.Label
$lblArgs.Location = New-Object System.Drawing.Point(20, 15)
$lblArgs.Size = New-Object System.Drawing.Size(300, 20)
$tabAdv.Controls.Add($lblArgs)

$argsBox = New-Object System.Windows.Forms.TextBox
$argsBox.Location = New-Object System.Drawing.Point(20, 35)
$argsBox.Size = New-Object System.Drawing.Size(485, 25)
$argsBox.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 60)
$argsBox.ForeColor = [System.Drawing.Color]::White
$tabAdv.Controls.Add($argsBox)

# FIX LAYOUT: Aumentata altezza e riposizionati elementi
$grpBooster = New-Object System.Windows.Forms.GroupBox
$grpBooster.Location = New-Object System.Drawing.Point(20, 70)
$grpBooster.Size = New-Object System.Drawing.Size(485, 100) # Aumentato da 80 a 100
$grpBooster.ForeColor = [System.Drawing.Color]::White
$grpBooster.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 50)
$tabAdv.Controls.Add($grpBooster)

$boosterCheck = New-Object System.Windows.Forms.CheckBox
$boosterCheck.Location = New-Object System.Drawing.Point(15, 20)
$boosterCheck.Size = New-Object System.Drawing.Size(250, 20)
$boosterCheck.ForeColor = [System.Drawing.Color]::LightGreen
$grpBooster.Controls.Add($boosterCheck)

$lblBoosterList = New-Object System.Windows.Forms.Label
$lblBoosterList.Location = New-Object System.Drawing.Point(15, 45) # Etichetta su riga dedicata
$lblBoosterList.Size = New-Object System.Drawing.Size(300, 20)
$lblBoosterList.Text = "App (csv):"
$grpBooster.Controls.Add($lblBoosterList)

$boosterBox = New-Object System.Windows.Forms.TextBox
$boosterBox.Location = New-Object System.Drawing.Point(15, 65) # Box sotto l'etichetta
$boosterBox.Size = New-Object System.Drawing.Size(455, 25)  # Box a larghezza intera
$boosterBox.BackColor = [System.Drawing.Color]::FromArgb(40, 40, 40)
$boosterBox.ForeColor = [System.Drawing.Color]::Gray
$grpBooster.Controls.Add($boosterBox)

# FIX LAYOUT: Spostato in basso a 180 (era 160)
$grpBackup = New-Object System.Windows.Forms.GroupBox
$grpBackup.Location = New-Object System.Drawing.Point(20, 180) 
$grpBackup.Size = New-Object System.Drawing.Size(485, 90)
$grpBackup.ForeColor = [System.Drawing.Color]::White
$grpBackup.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 50)
$tabAdv.Controls.Add($grpBackup)

$btnBackup = New-Object System.Windows.Forms.Button
$btnBackup.Location = New-Object System.Drawing.Point(15, 30)
$btnBackup.Size = New-Object System.Drawing.Size(220, 40)
$btnBackup.FlatStyle = "Flat"
$btnBackup.BackColor = [System.Drawing.Color]::Teal
$btnBackup.ForeColor = [System.Drawing.Color]::White
$grpBackup.Controls.Add($btnBackup)

$btnRestore = New-Object System.Windows.Forms.Button
$btnRestore.Location = New-Object System.Drawing.Point(250, 30)
$btnRestore.Size = New-Object System.Drawing.Size(220, 40)
$btnRestore.FlatStyle = "Flat"
$btnRestore.BackColor = [System.Drawing.Color]::DarkSlateGray
$btnRestore.ForeColor = [System.Drawing.Color]::White
$grpBackup.Controls.Add($btnRestore)

# FIX LAYOUT: Spostato in basso a 280 (era 260)
$grpPanic = New-Object System.Windows.Forms.GroupBox
$grpPanic.Location = New-Object System.Drawing.Point(20, 280)
$grpPanic.Size = New-Object System.Drawing.Size(485, 170)
$grpPanic.ForeColor = [System.Drawing.Color]::White
$grpPanic.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 50)
$tabAdv.Controls.Add($grpPanic)

$btnReShade = New-Object System.Windows.Forms.Button
$btnReShade.Location = New-Object System.Drawing.Point(20, 25)
$btnReShade.Size = New-Object System.Drawing.Size(210, 35)
$btnReShade.FlatStyle = "Flat"
$btnReShade.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 60)
$btnReShade.ForeColor = [System.Drawing.Color]::White
$grpPanic.Controls.Add($btnReShade)

$btnEditIni = New-Object System.Windows.Forms.Button
$btnEditIni.Location = New-Object System.Drawing.Point(240, 25)
$btnEditIni.Size = New-Object System.Drawing.Size(225, 35)
$btnEditIni.FlatStyle = "Flat"
$btnEditIni.BackColor = [System.Drawing.Color]::FromArgb(70, 70, 80)
$btnEditIni.ForeColor = [System.Drawing.Color]::White
$grpPanic.Controls.Add($btnEditIni)

$btnCleanCache = New-Object System.Windows.Forms.Button
$btnCleanCache.Location = New-Object System.Drawing.Point(20, 75)
$btnCleanCache.Size = New-Object System.Drawing.Size(445, 40)
$btnCleanCache.BackColor = [System.Drawing.Color]::DarkRed
$btnCleanCache.ForeColor = [System.Drawing.Color]::White
$btnCleanCache.FlatStyle = "Flat"
$btnCleanCache.Font = New-Object System.Drawing.Font("Arial", 10, [System.Drawing.FontStyle]::Bold)
$grpPanic.Controls.Add($btnCleanCache)

$closeCheck = New-Object System.Windows.Forms.CheckBox
$closeCheck.Location = New-Object System.Drawing.Point(20, 130)
$closeCheck.Size = New-Object System.Drawing.Size(400, 20)
$closeCheck.ForeColor = [System.Drawing.Color]::White
$grpPanic.Controls.Add($closeCheck)

# --- TAB: INFO ---
$btnLogs = New-Object System.Windows.Forms.Button
$btnLogs.Location = New-Object System.Drawing.Point(30, 40)
$btnLogs.Size = New-Object System.Drawing.Size(200, 35)
$btnLogs.FlatStyle = "Flat"
$btnLogs.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 70)
$btnLogs.ForeColor = [System.Drawing.Color]::White
$tabInfo.Controls.Add($btnLogs)

$btnMods = New-Object System.Windows.Forms.Button
$btnMods.Location = New-Object System.Drawing.Point(30, 90)
$btnMods.Size = New-Object System.Drawing.Size(200, 35)
$btnMods.FlatStyle = "Flat"
$btnMods.BackColor = [System.Drawing.Color]::FromArgb(60, 60, 70)
$btnMods.ForeColor = [System.Drawing.Color]::White
$tabInfo.Controls.Add($btnMods)

$linkWeb = New-Object System.Windows.Forms.LinkLabel
$linkWeb.Location = New-Object System.Drawing.Point(30, 150)
$linkWeb.Size = New-Object System.Drawing.Size(300, 25)
$linkWeb.LinkColor = [System.Drawing.Color]::LightSkyBlue
$linkWeb.ActiveLinkColor = [System.Drawing.Color]::Cyan
$tabInfo.Controls.Add($linkWeb)

$form.Add_FormClosing({ Save-Config })

# ==========================================
# 4. FUNZIONI DI LOGICA AGGIORNATA
# ==========================================

function Update-UI {
    $T = $langDict[$global:currentLang]
    
    $form.Text = $T.Title
    $titleLabel.Text = $T.Title
    $tabPlay.Text = $T.TabPlay
    $tabAdv.Text = $T.TabAdv
    $tabInfo.Text = $T.TabInfo
    
    $lblPlatform.Text = $T.Platform
    $lblPath.Text = $T.Path
    $browseBtn.Text = $T.Browse
    $launchBtn.Text = $T.Launch
    $grpVideo.Text = $T.VideoOpt
    $dx11Check.Text = $T.ForceDX11
    $windowCheck.Text = $T.Windowed
    $prioCheck.Text = $T.HighPrio
    $affinityCheck.Text = $T.Affinity
    $lblDisplay.Text = $T.DisplayMode
    
    $lblArgs.Text = $T.CustomArgs
    $closeCheck.Text = $T.CloseLauncher
    $grpPanic.Text = $T.Maintenance
    $btnCleanCache.Text = $T.ClearCache
    $btnEditIni.Text = $T.IniEdit
    
    $grpBooster.Text = $T.BoosterTitle
    $boosterCheck.Text = $T.BoosterCheck
    $lblBoosterList.Text = $T.BoosterList
    
    $grpBackup.Text = $T.BackupTitle
    $btnBackup.Text = $T.BtnBackup
    $btnRestore.Text = $T.BtnRestore
    
    # FIX: Ora usa le chiavi che ho aggiunto al dizionario
    $btnLogs.Text = $T.OpenLogs
    $btnMods.Text = $T.OpenMods
    $linkWeb.Text = $T.WebSite

    $sel = $vrCombo.SelectedIndex
    $vrCombo.Items.Clear()
    $vrCombo.Items.Add($T.Monitor)
    $vrCombo.Items.Add($T.OpenVR)
    $vrCombo.Items.Add($T.Oculus)
    if ($sel -ge 0 -and $sel -lt $vrCombo.Items.Count) { $vrCombo.SelectedIndex = $sel } else { $vrCombo.SelectedIndex = 0 }

    $statusLabel.Text = $T[$global:currentStatusKey]
    switch ($global:currentStatusKey) {
        "StatusReady" { $statusLabel.ForeColor = [System.Drawing.Color]::LightGreen }
        "StatusErr"   { $statusLabel.ForeColor = [System.Drawing.Color]::Red }
        "StatusSearch"{ $statusLabel.ForeColor = [System.Drawing.Color]::Yellow }
        "StatusManual"{ $statusLabel.ForeColor = [System.Drawing.Color]::Cyan }
        Default       { $statusLabel.ForeColor = [System.Drawing.Color]::White }
    }

    # ReShade UI Logic
    $currentPath = $pathTextBox.Text
    $btnReShade.Text = $T.ReShadeNo
    $btnReShade.ForeColor = [System.Drawing.Color]::Gray
    $btnReShade.BackColor = [System.Drawing.Color]::FromArgb(50, 50, 60)

    if (-not [string]::IsNullOrWhiteSpace($currentPath) -and (Test-Path $currentPath)) {
        $dir = [System.IO.Path]::GetDirectoryName($currentPath)
        if (Test-Path "$dir\dxgi.dll") {
            $btnReShade.Text = $T.ReShadeOn
            $btnReShade.ForeColor = [System.Drawing.Color]::LightGreen
            $btnReShade.BackColor = [System.Drawing.Color]::FromArgb(30, 60, 30)
        } elseif (Test-Path "$dir\dxgi.dll.off") {
            $btnReShade.Text = $T.ReShadeOff
            $btnReShade.ForeColor = [System.Drawing.Color]::Orange
            $btnReShade.BackColor = [System.Drawing.Color]::FromArgb(60, 40, 10)
        }
    }
    $form.Refresh()
}

$langButton.add_Click({
    if ($global:currentLang -eq "IT") { $global:currentLang = "EN" } else { $global:currentLang = "IT" }
    Update-UI
})

function Find-Game {
    $T = $langDict[$global:currentLang]
    $global:currentStatusKey = "StatusSearch"
    Update-UI
    
    $searchPaths = @(
        "C:\Program Files (x86)\Steam\steamapps\common\Assetto Corsa Rally\acr\Binaries\Win64\acr.exe",
        "C:\Program Files\Steam\steamapps\common\Assetto Corsa Rally\acr\Binaries\Win64\acr.exe",
        "D:\SteamLibrary\steamapps\common\Assetto Corsa Rally\acr\Binaries\Win64\acr.exe",
        "D:\Games\Steam\steamapps\common\Assetto Corsa Rally\acr\Binaries\Win64\acr.exe",
        "C:\Program Files\Epic Games\AssettoCorsaRally\acr\Binaries\Win64\acr.exe"
    )

    $found = $false
    foreach ($p in $searchPaths) {
        [System.Windows.Forms.Application]::DoEvents()
        if (Test-Path $p) {
            $pathTextBox.Text = $p
            $global:currentStatusKey = "StatusReady"
            $found = $true
            try { $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($p) } catch {}
            break
        }
    }

    if (-not $found) { 
        $pathTextBox.Text = ""
        $global:currentStatusKey = "StatusErr"
        $res = [System.Windows.Forms.MessageBox]::Show($T.MissingMsg, "ACR Launcher", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
        if ($res -eq "Yes") { Start-Process "https://assettocorsa.gg/assetto-corsa-rally/" }
    }
    Update-UI 
}

$browseBtn.add_Click({
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = "ACR Executable (acr.exe)|acr.exe"
    $ofd.Title = "Select acr.exe"
    if ($ofd.ShowDialog() -eq "OK") {
        $selectedPath = $ofd.FileName
        $parentDir = [System.IO.Path]::GetDirectoryName($selectedPath)
        $deepPath = Join-Path $parentDir "acr\Binaries\Win64\acr.exe"
        
        if (Test-Path $deepPath) { $pathTextBox.Text = $deepPath } else { $pathTextBox.Text = $selectedPath }

        $global:currentStatusKey = "StatusManual"
        Update-UI
        try { $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($pathTextBox.Text) } catch {}
    }
})

$btnBackup.add_Click({
    $T = $langDict[$global:currentLang]
    if (Test-Path $global:saveDir) {
        try {
            $dateStr = Get-Date -Format "yyyyMMdd_HHmm"
            $destZip = Join-Path $backupDir "Backup_Save_$dateStr.zip"
            [System.IO.Compression.ZipFile]::CreateFromDirectory($global:saveDir, $destZip)
            [System.Windows.Forms.MessageBox]::Show("$($T.BackupMsg) $destZip", "Success")
        } catch {
             [System.Windows.Forms.MessageBox]::Show("Backup Error: $_", "Error")
        }
    } else {
        [System.Windows.Forms.MessageBox]::Show("Save folder not found: $global:saveDir", "Error")
    }
})

$btnRestore.add_Click({
    $T = $langDict[$global:currentLang]
    $latest = Get-ChildItem -Path $backupDir -Filter "*.zip" | Sort-Object CreationTime -Descending | Select-Object -First 1
    if ($latest) {
        $res = [System.Windows.Forms.MessageBox]::Show("Restore $($latest.Name)? This overwrites current saves.", "Confirm", [System.Windows.Forms.MessageBoxButtons]::YesNo)
        if ($res -eq "Yes") {
            try {
                Expand-Archive -Path $latest.FullName -DestinationPath $global:saveDir -Force
                [System.Windows.Forms.MessageBox]::Show($T.RestoreMsg, "Success")
            } catch {
                [System.Windows.Forms.MessageBox]::Show("Restore Error: $_", "Error")
            }
        }
    } else {
        [System.Windows.Forms.MessageBox]::Show($T.NoBackup, "Info")
    }
})

$btnEditIni.add_Click({
    $iniFile = "$global:gameConfigDir\GameUserSettings.ini"
    if (Test-Path $iniFile) { Invoke-Item $iniFile } 
    else { [System.Windows.Forms.MessageBox]::Show("Config file not found yet. Run the game once.", "Info") }
})

$btnReShade.add_Click({
    $currentPath = $pathTextBox.Text
    if (-not [string]::IsNullOrWhiteSpace($currentPath)) {
        $dir = [System.IO.Path]::GetDirectoryName($currentPath)
        $on = "$dir\dxgi.dll"; $off = "$dir\dxgi.dll.off"
        if (Test-Path $on) { Rename-Item $on "dxgi.dll.off" } elseif (Test-Path $off) { Rename-Item $off "dxgi.dll" }
        Update-UI 
    }
})

$btnCleanCache.add_Click({
    $T = $langDict[$global:currentLang]
    $res = [System.Windows.Forms.MessageBox]::Show($T.CleanConfirm, "Warning", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
    if ($res -eq "Yes") {
        if (Test-Path $global:gameConfigDir) {
            Get-ChildItem -Path $global:gameConfigDir -Filter "*.ini" | Remove-Item -Force
            [System.Windows.Forms.MessageBox]::Show("Cache cleaned.", "Success")
        }
    }
})

$launchBtn.add_Click({
    $exe = $pathTextBox.Text
    $T = $langDict[$global:currentLang]
    
    if ([string]::IsNullOrWhiteSpace($exe) -or -not (Test-Path $exe)) {
        $global:currentStatusKey = "StatusErr"; Update-UI
        [System.Windows.Forms.MessageBox]::Show($T.StatusErr, "Error", 0, 16)
        return
    }
    
    $procName = [System.IO.Path]::GetFileNameWithoutExtension($exe)
    if (Get-Process -Name $procName -ErrorAction SilentlyContinue) {
        [System.Windows.Forms.MessageBox]::Show($T.RunningWarn, "Warning", 0, 48)
        return
    }

    Save-Config
    
    # --- GAME BOOSTER LOGIC ---
    if ($boosterCheck.Checked -and $boosterBox.Text.Length -gt 0) {
        $apps = $boosterBox.Text.Split(',')
        foreach ($app in $apps) {
            $cleanName = $app.Trim().Replace(".exe", "")
            Stop-Process -Name $cleanName -Force -ErrorAction SilentlyContinue
        }
    }

    $argsList = @()
    if ($dx11Check.Checked) { $argsList += "-dx11" }
    if ($windowCheck.Checked) { $argsList += "-windowed" }
    switch ($vrCombo.SelectedIndex) {
        1 { $argsList += "-openvr"; $argsList += "-vr" }
        2 { $argsList += "-oculus"; $argsList += "-vr" }
    }
    if (-not [string]::IsNullOrWhiteSpace($argsBox.Text)) { $argsList += ($argsBox.Text.Trim() -split '\s+') }

    try {
        $global:currentStatusKey = "StatusRun"; Update-UI
        
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $exe
        $psi.Arguments = $argsList -join " "
        $psi.WorkingDirectory = [System.IO.Path]::GetDirectoryName($exe)
        $psi.UseShellExecute = $true 

        Write-Host "Avvio: $exe"
        [System.Diagnostics.Process]::Start($psi) | Out-Null
        
        # --- FIX PRIORITÀ & AFFINITÀ ---
        if ($prioCheck.Checked -or $affinityCheck.Checked) {
            $maxRetries = 15
            $tweaked = $false
            for ($i = 0; $i -lt $maxRetries; $i++) {
                Start-Sleep -Seconds 1
                $runningProcs = Get-Process -Name "acr" -ErrorAction SilentlyContinue
                
                if ($runningProcs) {
                    foreach ($p in $runningProcs) {
                        try {
                            if ($prioCheck.Checked -and $p.PriorityClass -ne [System.Diagnostics.ProcessPriorityClass]::High) {
                                $p.PriorityClass = [System.Diagnostics.ProcessPriorityClass]::High
                                Write-Host "Priorità HIGH impostata."
                            }
                            
                            if ($affinityCheck.Checked) {
                                # Crea una maschera a 64-bit (long) vuota
                                $bitmask = [long]0
                                $coreCount = [System.Environment]::ProcessorCount

                                # Ciclo che avanza di 2 in 2 (0, 2, 4...) per saltare i core logici (HyperThreading)
                                for ($c = 0; $c -lt $coreCount; $c += 2) {
                                    # Usa lo shift bitwise (-shl) che è matematicamente preciso per la CPU
                                    $bitmask = $bitmask -bor ([long]1 -shl $c)
                                }

                                # Applica la maschera calcolata
                                $p.ProcessorAffinity = [IntPtr]$bitmask
                                Write-Host "Affinità impostata su Core Fisici (Mask: $bitmask)"
                            }
                            $tweaked = $true
                        } catch {}
                    }
                    if ($tweaked) { break }
                }
            }
        }

        if ($closeCheck.Checked) { 
            Start-Sleep -Milliseconds 1000; $form.Close() 
        } else {
            Start-Sleep -Seconds 2
            if (Get-Process -Name "acr" -ErrorAction SilentlyContinue) { $global:currentStatusKey = "StatusRun" } 
            else { $global:currentStatusKey = "StatusReady" }
            Update-UI
        }

    } catch {
        $global:currentStatusKey = "StatusErr"; Update-UI
        [System.Windows.Forms.MessageBox]::Show("Error: $($_.Exception.Message)", "Error", 0, 16)
    }
})

$linkWeb.add_Click({ Start-Process "https://assettocorsa.gg/assetto-corsa-rally/" })
$btnLogs.add_Click({ $l="$env:LOCALAPPDATA\acr\Saved\Logs"; if(!(Test-Path $l)){New-Item -ItemType Dir -Path $l|Out-Null}; Invoke-Item $l })
$btnMods.add_Click({ $c=$pathTextBox.Text; if($c){$d=Split-Path $c -Parent; $m=Join-Path $d "mods"; if(!(Test-Path $m)){$m=Join-Path $d "content"}; if(Test-Path $m){Invoke-Item $m}else{Invoke-Item $d}} })

# ==========================================
# 5. CARICAMENTO CONFIG & UPDATE CHECK
# ==========================================
$savedConfig = Get-Config
if ($savedConfig) {
    if ($savedConfig.Path) { $pathTextBox.Text = $savedConfig.Path }
    if ($savedConfig.DX11 -ne $null) { $dx11Check.Checked = $savedConfig.DX11 }
    if ($savedConfig.Windowed -ne $null) { $windowCheck.Checked = $savedConfig.Windowed }
    if ($savedConfig.HighPrio -ne $null) { $prioCheck.Checked = $savedConfig.HighPrio }
    if ($savedConfig.Affinity -ne $null) { $affinityCheck.Checked = $savedConfig.Affinity }
    if ($savedConfig.VRMode -ne $null) { $vrCombo.SelectedIndex = $savedConfig.VRMode }
    if ($savedConfig.CloseOnStart -ne $null) { $closeCheck.Checked = $savedConfig.CloseOnStart }
    if ($savedConfig.CustomArgs) { $argsBox.Text = $savedConfig.CustomArgs }
    if ($savedConfig.Language) { $global:currentLang = $savedConfig.Language }
    if ($savedConfig.BoosterEnabled -ne $null) { $boosterCheck.Checked = $savedConfig.BoosterEnabled }
    if ($savedConfig.BoosterApps) { $boosterBox.Text = $savedConfig.BoosterApps } 
    else { $boosterBox.Text = $langDict["EN"].BoosterDefault }
} else {
    $boosterBox.Text = $langDict["EN"].BoosterDefault
}

if (-not [string]::IsNullOrWhiteSpace($global:UpdateUrl)) {
    try {
        $web = New-Object System.Net.WebClient
        $onlineVer = $web.DownloadString($global:UpdateUrl).Trim()
        if ($onlineVer -ne $global:LauncherVersion) {
            [System.Windows.Forms.MessageBox]::Show("New version available: $onlineVer", "Update")
        }
    } catch {}
}

if ([string]::IsNullOrWhiteSpace($pathTextBox.Text)) { Find-Game } 
elseif (Test-Path $pathTextBox.Text) { $global:currentStatusKey = "StatusReady"; try{$form.Icon=[System.Drawing.Icon]::ExtractAssociatedIcon($pathTextBox.Text)}catch{} } 
else { Find-Game }

Update-UI
[void]$form.ShowDialog()